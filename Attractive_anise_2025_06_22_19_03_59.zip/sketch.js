let sementes = 10;
let plantadas = [];

function setup() {
  createCanvas(600, 400);
  background(200, 255, 200);

  // Texto de instrução
  fill(0);
  textSize(20);
  text("Use o mouse para plantar sementes", 150, 30);
  text("Sementes: " + sementes, 450, 30);
}

function draw() {
  // Se houver sementes plantadas, desenhar as plantações
  for (let i = 0; i < plantadas.length; i++) {
    plantadas[i].display();
  }

  // Checa o estado das plantações
  for (let i = 0; i < plantadas.length; i++) {
    plantadas[i].grow();
  }
}

function mousePressed() {
  // Plantar sementes se houver
  if (sementes > 0) {
    let p = new Plant(mouseX, mouseY);
    plantadas.push(p);
    sementes--;
  }
}

class Plant {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 20;
    this.growthStage = 0;
  }

  // Método para aumentar o crescimento da planta
  grow() {
    if (this.growthStage < 3) {
      this.growthStage++;
      this.size += 10;
    }
  }

  // Método para desenhar a planta
  display() {
    fill(34, 139, 34); // Cor verde para a planta
    ellipse(this.x, this.y, this.size, this.size);
  }
}

